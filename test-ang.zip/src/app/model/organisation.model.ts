export class Organisation {
    id: string;
    title: string;
    description: string;
}